// --------------------------------------------------------------------
//			Archetypal theme for K-Meleon by R.J.J. III				  
// --------------------------------------------------------------------
//
// .index	#:	Render the toolbars in this order moving from left to 
//				right and top and to bottom.
// .break	0:	Place the toolbar to the right of the previous toolbar 
//				if it fits.
//			1:	Place toolbar on a new line starting at the left edge 
//				of the browser window.
// .size	#:	Give the toolbar this minimum width. K-Meleon should not
//				make toolbars too small to contain all of their buttons.
//				You'll use this if you need to create space between
//				buttons on the toolbar. You can set it to a very large
//				number to right-align the following icons. Look at the
//				"URL Bar" for an example.
// .visibility:	This will hide the toolbar if "false" and will display
//				it if "true".
//
// --------------------------------------------------------------------



//Full-size menu bar. break=1 to take up a full line
pref("kmeleon.toolband.Menu.break", 1);
pref("kmeleon.toolband.Menu.index", 1);



//Navigation menu for the top-left
pref("kmeleon.toolband.&Main Bar.break", 1);
pref("kmeleon.toolband.&Main Bar.index", 2);
pref("kmeleon.toolband.&Main Bar.size", 275);
pref("kmeleon.toolband.&Main Bar.visibility", true);

//Large tools menus beside navigation
pref("kmeleon.toolband.Tool Buttons.break", 0);
pref("kmeleon.toolband.Tool Buttons.index", 3);
pref("kmeleon.toolband.Tool Buttons.size", 275);

//Search and help/search buttons
pref("kmeleon.toolband.&Search Buttons.break", 0);
pref("kmeleon.toolband.&Search Buttons.index", 4);
pref("kmeleon.toolband.&Search Buttons.size", 3333);

//Compact menu for the top-right
pref("kmeleon.toolband.Menu Button.break", 0);
pref("kmeleon.toolband.Menu Button.index", 5);
pref("kmeleon.toolband.Menu Button.size", 290);


//Small button to lock/unlock toolbars
pref("kmeleon.toolband.Lock.break", 1);
pref("kmeleon.toolband.Lock.index", 6);
pref("kmeleon.toolband.Lock.size", 29);
pref("kmeleon.toolband.Lock.visibility", true);

//Bookmarks button
pref("kmeleon.toolband.Bookmark Buttons.break", 0);
pref("kmeleon.toolband.Bookmark Buttons.index", 7);
pref("kmeleon.toolband.Bookmark Buttons.size", 44);

//Address bar for the top-middle
pref("kmeleon.toolband.URL Bar.break", 0);
pref("kmeleon.toolband.URL Bar.index", 8);
pref("kmeleon.toolband.URL Bar.size", 3333);
pref("kmeleon.toolband.URL Bar.visibility", true);

//Search button beside URL bar
pref("kmeleon.toolband.Search URL Bar.break", 0);
pref("kmeleon.toolband.Search URL Bar.index", 9);
pref("kmeleon.toolband.Search URL Bar.size", 89);
pref("kmeleon.toolband.Search URL Bar.visibility", true);

// Go button. It's the configuration button because that's the 
// default location for JSbridge buttons in XUL-based extensions.
pref("kmeleon.toolband.Browser Con&figuration.break", 0);
pref("kmeleon.toolband.Browser Con&figuration.index", 10);
pref("kmeleon.toolband.Browser Con&figuration.size", 44);
pref("kmeleon.toolband.Browser Con&figuration.visibility", true);




//Privacy bar. Next line. This is the old style Privacy Bar.
pref("kmeleon.toolband.&Privacy Bar.break", 1);
pref("kmeleon.toolband.&Privacy Bar.index", 11);



//Bookmarks bar. 
pref("kmeleon.toolband.Bookmarks.break", 1);
pref("kmeleon.toolband.Bookmarks.index", 12);



//Tabs bar.
pref("kmeleon.toolband.Tabs.break", 1);
pref("kmeleon.toolband.Tabs.index", 13);
pref("kmeleon.toolband.Tabs.size", 3333);

// Tab controls. These will stretch offscreen if attached
// to the actual tab bar.
pref("kmeleon.toolband.Tab/&Window Buttons.break", 0);
pref("kmeleon.toolband.Tab/&Window Buttons.index", 14);
pref("kmeleon.toolband.Tab/&Window Buttons.size", 137);



//Global settings:
pref("kmeleon.general.toolbars_locked", false);